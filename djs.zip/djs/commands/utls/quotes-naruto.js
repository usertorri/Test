const { ApplicationCommandType, ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require('discord.js');
const naruto = require('quotes-naruto');

module.exports = {
	name: 'quotes-naruto',
	description: "Рандомная цитата",
	cooldown: 3000,
	userPerms: [],
	botPerms: [],
	run: async (client, message, args) => {
        const getButtons = (toggle = false, choice) => {
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                        .setLabel('Обновить')
                        .setCustomId('green')
                        .setStyle(toggle == true && choice == 'green' ? 'Secondary' : 'Success')
                        .setDisabled(toggle)
            );
            return row;
        }

        const embed = new EmbedBuilder()
        .setTitle(message.author.tag)
        .setDescription(naruto.queotesNameAll('right', ': ', 'ru'))
        .setColor('#2f3136')
        .setTimestamp()
        
        message.reply({ embeds: [embed], components: [getButtons()] })
        .then((m) => {
            const collector = m.createMessageComponentCollector({ time: 600000 });
            collector.on('collect', async (i) => {
                if (!i.isButton()) return;
                await i.deferUpdate();
                if (i.user.id !== message.author.id) return i.followUp({ content: `Эти кнопки не для вас!`, ephemeral: true });
                const embed1 = new EmbedBuilder()
        .setTitle(message.author.tag)
        .setDescription(naruto.queotesNameAll('right', ': ', 'ru'))
        .setColor('#2f3136')
        .setTimestamp()
              i.editReply({embeds: [embed1], components: [getButtons()] })
            });
            collector.on('end', (collected, reason) => {
                if (reason === 'user') {
                    return message.followUp({ content: 'Данное взаимодействия больше не доступне', ephemeral: true });
                }
                if(reason === 'time') {
                    return;
                }
            });
        });
	}
};