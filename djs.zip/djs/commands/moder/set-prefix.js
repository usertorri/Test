const { EmbedBuilder } = require('discord.js');
const { Create } = require('database-sempai');

const db = new Create({
  path: "./database",
  table: ["users", "server"]
});

module.exports = {
	name: 'set-prefix',
	description: "Check bo",
	cooldown: 3000,
	userPerms: [],
	botPerms: [],
	run: async (client, message, args) => {
	  const pre = message.content.split(' ').slice(1).join(' ');
	  if ( message.member.permissions.any("Administrator", true) === true) {
    if (pre === "") {
      message.reply("Укажите префикс");
    } else {
      if (pre.length <= 10) {
      message.reply(`Префикс изменён на: ${pre.trim()}`);
      db.set('server', `prefix_${message.guild.id}`, `${pre.trim()}`);
    } else {
     const error = new EmbedBuilder()
    .setTitle(`${message.author.tag}`)
    .setDescription('Максимальное количество символов 10')
    .setTimestamp()
    .setColor('#ff0000');
    
 message.reply({ embeds: [error] });
   }
    }
  } else {
    const error = new EmbedBuilder()
    .setTitle(`${message.author.tag}`)
    .setDescription('Вам нужно право администратора')
    .setTimestamp()
    .setColor('#ff0000');
    
 message.reply({ embeds: [error] });
}
}};