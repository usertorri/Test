const { EmbedBuilder } = require('discord.js');

module.exports = {
	name: 'help',
	description: "Check bot's ping.",
	cooldown: 3000,
	userPerms: [],
	botPerms: [],
	run: async (client, message, args) => {
	  const prefix = client.db.get('server', `prefix_${message.guild.id}`)
	  const help = new EmbedBuilder(message.embeds[0]);
    help.addFields({name:"Доступные команды", value:`${prefix}ping - покажет задержку бота\n${prefix}set-prefix - изменить префикс\n${prefix}invite - пригласить бота\n${prefix}quotes-naruto - рандомная цитата из наруто`, inline:false});
    help.addFields({name:"Команды в разработке", value:`${prefix}flags - угадать странну по флагу`, inline:false})
    .setTitle('Помощь по командам')
    .setTimestamp()
    .setColor('#2f3136');
 
 message.reply({ embeds: [help] });
		/*const msg = await message.reply('Pinging...')
		await msg.edit(`Pong! **${client.ws.ping} ms**`)*/
	}
};