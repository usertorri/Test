const { EmbedBuilder } = require('discord.js');
module.exports = {
	name: 'ping',
	description: "Check bot's ping.",
	cooldown: 3000,
	userPerms: [],
	botPerms: [],
	run: async (client, message, args) => {
	  const ping = new EmbedBuilder()
    .setDescription(`Пинг: ${client.ws.ping}ms`)
    .setTitle('Задержка бота')
    .setTimestamp()
    .setColor('#2f3136');
    
    message.reply({ embeds: [ping] });
		/*const msg = await message.reply('Pinging...')
		await msg.edit(`Pong! **${client.ws.ping} ms**`)*/
	}
};