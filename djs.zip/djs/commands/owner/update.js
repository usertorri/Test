const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const owner = 907201684537757701;

module.exports = {
	name: 'update',
	description: "Пригласить бота",
	cooldown: 3000,
	userPerms: [],
	botPerms: [],
	run: async (client, message, args) => {
	  if(owner==message.author.id) {
		message.reply("Бот перезапустится")
		setTimeout(function() {
		  process.on("exit", () => {
            require("child_process").spawn(process.argv.shift(), process.argv, {
                cwd: process.cwd(),
                detached: true,
                stdio: "inherit",
            });
        });
        process.exit();
		}, 2000);
	}
}
};
