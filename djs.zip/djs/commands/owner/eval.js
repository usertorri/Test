const { EmbedBuilder } = require('discord.js');
const owner = 907201684537757701;

module.exports = {
	name: 'eval',
	description: "Check bot's ping.",
	cooldown: 3000,
	userPerms: [],
	botPerms: [],
	run: async (client, message, args) => {
//	  const d = message || client || args
	if(owner==message.author.id) {
  if( message.author.bot === false ) {
    try {
      let code = message.content.split(' ').slice(1).join(' ');
      message.channel.send(`Результат:  ${eval(code)}`)
    } catch(error)  {
      if (error.length >= 50) {
      message.channel.send(error)
      }
      console.error(error)
    }
  }
  } else {
    console.log(message.author.tag + " Ахуел")
  }
	}
};